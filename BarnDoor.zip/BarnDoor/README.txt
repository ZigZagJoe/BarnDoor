This is the AVR code. See main info text or look at the comments in the source.
