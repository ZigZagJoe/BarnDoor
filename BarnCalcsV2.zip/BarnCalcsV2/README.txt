This is the program for calculating the table. See the main readme for an overall description. 
